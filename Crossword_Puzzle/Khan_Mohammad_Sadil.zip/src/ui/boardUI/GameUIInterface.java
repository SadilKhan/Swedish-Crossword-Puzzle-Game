package ui.boardUI;

interface GameUIInterface {
	// Interface for GameUI interface
	
	void createSquarePanel();
	void createCluesPanel();
	void createSolutionPanel();

}
